import { NextRequest, NextResponse } from 'next/server';
import { getRequestById, updateRequest } from '@/lib/database';
import { authenticateRequest } from '@/lib/auth';
import { createApiResponse } from '@/lib/utils';

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const user = authenticateRequest(request);
    if (!user) {
      return NextResponse.json(
        createApiResponse(false, null, 'Authentication required'),
        { status: 401 }
      );
    }

    const bookRequest = getRequestById(params.id);

    if (!bookRequest) {
      return NextResponse.json(
        createApiResponse(false, null, 'Request not found'),
        { status: 404 }
      );
    }

    // Check if user can access this request
    if (user.role !== 'admin' && bookRequest.user_id !== user.id) {
      return NextResponse.json(
        createApiResponse(false, null, 'Access denied'),
        { status: 403 }
      );
    }

    return NextResponse.json(
      createApiResponse(true, bookRequest)
    );
  } catch (error) {
    console.error('Get request error:', error);
    return NextResponse.json(
      createApiResponse(false, null, 'Internal server error'),
      { status: 500 }
    );
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const user = authenticateRequest(request);
    if (!user || user.role !== 'admin') {
      return NextResponse.json(
        createApiResponse(false, null, 'Admin access required'),
        { status: 403 }
      );
    }

    const { status, rejectionReason } = await request.json();

    if (!status || !['approved', 'rejected'].includes(status)) {
      return NextResponse.json(
        createApiResponse(false, null, 'Valid status (approved/rejected) is required'),
        { status: 400 }
      );
    }

    const updates: any = {
      status,
      approved_by: user.id
    };

    if (status === 'approved') {
      updates.approved_at = new Date().toISOString();
    } else if (status === 'rejected') {
      updates.rejected_at = new Date().toISOString();
      updates.rejection_reason = rejectionReason;
    }

    const updatedRequest = updateRequest(params.id, updates);

    if (!updatedRequest) {
      return NextResponse.json(
        createApiResponse(false, null, 'Request not found'),
        { status: 404 }
      );
    }

    return NextResponse.json(
      createApiResponse(true, updatedRequest, null, `Request ${status} successfully`)
    );
  } catch (error) {
    console.error('Update request error:', error);
    return NextResponse.json(
      createApiResponse(false, null, 'Internal server error'),
      { status: 500 }
    );
  }
}
