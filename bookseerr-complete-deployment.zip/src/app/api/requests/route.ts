import { NextRequest, NextResponse } from 'next/server';
import { v4 as uuidv4 } from 'uuid';
import { 
  getAllRequests, 
  getRequestsByUserId, 
  createRequest, 
  getBookById,
  updateRequest
} from '@/lib/database';
import { authenticateRequest } from '@/lib/auth';
import { createApiResponse } from '@/lib/utils';

export async function GET(request: NextRequest) {
  try {
    const user = authenticateRequest(request);
    if (!user) {
      return NextResponse.json(
        createApiResponse(false, null, 'Authentication required'),
        { status: 401 }
      );
    }

    const { searchParams } = new URL(request.url);
    const userId = searchParams.get('userId');
    const status = searchParams.get('status');

    let requests;

    if (user.role === 'admin') {
      // Admin can see all requests
      if (userId) {
        requests = getRequestsByUserId(userId);
      } else {
        requests = getAllRequests();
      }
    } else {
      // Users can only see their own requests
      requests = getRequestsByUserId(user.id);
    }

    // Filter by status if provided
    if (status) {
      requests = requests.filter(req => req.status === status);
    }

    // Populate with book and user info
    const populatedRequests = requests.map(req => {
      const book = getBookById(req.book_id);
      return {
        ...req,
        book: book ? {
          id: book.id,
          title: book.title,
          author: book.author,
          imageUrl: book.image_url
        } : null
      };
    });

    return NextResponse.json(
      createApiResponse(true, populatedRequests)
    );
  } catch (error) {
    console.error('Get requests error:', error);
    return NextResponse.json(
      createApiResponse(false, null, 'Internal server error'),
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const user = authenticateRequest(request);
    if (!user) {
      return NextResponse.json(
        createApiResponse(false, null, 'Authentication required'),
        { status: 401 }
      );
    }

    const { bookId, notes } = await request.json();

    if (!bookId) {
      return NextResponse.json(
        createApiResponse(false, null, 'Book ID is required'),
        { status: 400 }
      );
    }

    // Check if book exists
    const book = getBookById(bookId);
    if (!book) {
      return NextResponse.json(
        createApiResponse(false, null, 'Book not found'),
        { status: 404 }
      );
    }

    // Check if user already has a pending request for this book
    const existingRequests = getRequestsByUserId(user.id);
    const existingRequest = existingRequests.find(
      req => req.book_id === bookId && req.status === 'pending'
    );

    if (existingRequest) {
      return NextResponse.json(
        createApiResponse(false, null, 'You already have a pending request for this book'),
        { status: 409 }
      );
    }

    // Create new request
    const newRequest = createRequest({
      id: uuidv4(),
      book_id: bookId,
      user_id: user.id,
      status: 'pending',
      notes
    });

    return NextResponse.json(
      createApiResponse(true, newRequest, null, 'Request submitted successfully')
    );
  } catch (error) {
    console.error('Create request error:', error);
    return NextResponse.json(
      createApiResponse(false, null, 'Internal server error'),
      { status: 500 }
    );
  }
}
