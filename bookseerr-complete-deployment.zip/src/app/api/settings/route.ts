import { NextRequest, NextResponse } from 'next/server';
import { getSetting, setSetting } from '@/lib/database';
import { authenticateRequest } from '@/lib/auth';
import { createApiResponse } from '@/lib/utils';

export async function GET(request: NextRequest) {
  try {
    const user = authenticateRequest(request);
    if (!user) {
      return NextResponse.json(
        createApiResponse(false, null, 'Authentication required'),
        { status: 401 }
      );
    }

    const { searchParams } = new URL(request.url);
    const key = searchParams.get('key');

    if (key) {
      const value = getSetting(key);
      const parsedValue = value ? JSON.parse(value) : null;

      return NextResponse.json(
        createApiResponse(true, { [key]: parsedValue })
      );
    }

    // Return common settings
    const settings = {
      general: getSetting('general') ? JSON.parse(getSetting('general')!) : {
        applicationTitle: 'Bookseerr',
        applicationUrl: '',
        enableRegistration: true,
        defaultPermissions: {
          canRequest: true,
          canApprove: false,
          canManageUsers: false,
          canConfigureSettings: false,
          maxRequests: 10
        }
      },
      readarr: getSetting('readarr') ? JSON.parse(getSetting('readarr')!) : {
        url: '',
        apiKey: '',
        rootFolder: '/books',
        qualityProfile: 'Standard',
        enabled: false
      },
      qbittorrent: getSetting('qbittorrent') ? JSON.parse(getSetting('qbittorrent')!) : {
        url: '',
        username: '',
        password: '',
        downloadPath: '/downloads',
        category: 'books',
        enabled: false
      }
    };

    return NextResponse.json(
      createApiResponse(true, settings)
    );
  } catch (error) {
    console.error('Get settings error:', error);
    return NextResponse.json(
      createApiResponse(false, null, 'Internal server error'),
      { status: 500 }
    );
  }
}

export async function PUT(request: NextRequest) {
  try {
    const user = authenticateRequest(request);
    if (!user || user.role !== 'admin') {
      return NextResponse.json(
        createApiResponse(false, null, 'Admin access required'),
        { status: 403 }
      );
    }

    const settings = await request.json();

    // Save each setting section
    for (const [key, value] of Object.entries(settings)) {
      setSetting(key, JSON.stringify(value));
    }

    return NextResponse.json(
      createApiResponse(true, settings, null, 'Settings updated successfully')
    );
  } catch (error) {
    console.error('Update settings error:', error);
    return NextResponse.json(
      createApiResponse(false, null, 'Internal server error'),
      { status: 500 }
    );
  }
}
