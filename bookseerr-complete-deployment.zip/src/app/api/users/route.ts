import { NextRequest, NextResponse } from 'next/server';
import { getAllUsers } from '@/lib/database';
import { authenticateRequest } from '@/lib/auth';
import { createApiResponse } from '@/lib/utils';

export async function GET(request: NextRequest) {
  try {
    const user = authenticateRequest(request);
    if (!user || user.role !== 'admin') {
      return NextResponse.json(
        createApiResponse(false, null, 'Admin access required'),
        { status: 403 }
      );
    }

    const users = getAllUsers();

    // Remove sensitive information
    const safeUsers = users.map(dbUser => ({
      id: dbUser.id,
      username: dbUser.username,
      email: dbUser.email,
      role: dbUser.role,
      createdAt: dbUser.created_at,
      updatedAt: dbUser.updated_at,
      avatar: dbUser.avatar,
      permissions: dbUser.permissions ? JSON.parse(dbUser.permissions) : null
    }));

    return NextResponse.json(
      createApiResponse(true, safeUsers)
    );
  } catch (error) {
    console.error('Get users error:', error);
    return NextResponse.json(
      createApiResponse(false, null, 'Internal server error'),
      { status: 500 }
    );
  }
}
