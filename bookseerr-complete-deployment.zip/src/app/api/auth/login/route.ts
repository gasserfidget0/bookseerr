import { NextRequest, NextResponse } from 'next/server';
import { getUserByUsername, getUserByEmail } from '@/lib/database';
import { verifyPassword, generateToken, databaseUserToUser } from '@/lib/auth';
import { createApiResponse } from '@/lib/utils';

export async function POST(request: NextRequest) {
  try {
    const { username, password } = await request.json();

    if (!username || !password) {
      return NextResponse.json(
        createApiResponse(false, null, 'Username and password are required'),
        { status: 400 }
      );
    }

    // Find user by username or email
    let dbUser = getUserByUsername(username);
    if (!dbUser && username.includes('@')) {
      dbUser = getUserByEmail(username);
    }

    if (!dbUser) {
      return NextResponse.json(
        createApiResponse(false, null, 'Invalid credentials'),
        { status: 401 }
      );
    }

    // Verify password
    const isPasswordValid = verifyPassword(password, dbUser.password_hash);
    if (!isPasswordValid) {
      return NextResponse.json(
        createApiResponse(false, null, 'Invalid credentials'),
        { status: 401 }
      );
    }

    // Generate JWT token
    const token = generateToken(dbUser);
    const user = databaseUserToUser(dbUser);

    const response = NextResponse.json(
      createApiResponse(true, {
        user,
        token,
        expiresAt: new Date(Date.now() + parseInt(process.env.JWT_EXPIRES_IN || '3600') * 1000).toISOString()
      }, null, 'Login successful')
    );

    // Set HTTP-only cookie
    const maxAge = parseInt(process.env.JWT_EXPIRES_IN || '3600');
    response.cookies.set('auth-token', token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      maxAge,
      path: '/'
    });

    return response;
  } catch (error) {
    console.error('Login error:', error);
    return NextResponse.json(
      createApiResponse(false, null, 'Internal server error'),
      { status: 500 }
    );
  }
}
