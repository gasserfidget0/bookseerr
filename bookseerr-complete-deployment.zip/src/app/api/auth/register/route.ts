import { NextRequest, NextResponse } from 'next/server';
import { v4 as uuidv4 } from 'uuid';
import { createUser, getUserByUsername, getUserByEmail } from '@/lib/database';
import { hashPassword, generateToken, databaseUserToUser } from '@/lib/auth';
import { createApiResponse, isValidEmail, isValidUsername, isValidPassword } from '@/lib/utils';

export async function POST(request: NextRequest) {
  try {
    const { username, email, password } = await request.json();

    // Validation
    if (!username || !email || !password) {
      return NextResponse.json(
        createApiResponse(false, null, 'Username, email, and password are required'),
        { status: 400 }
      );
    }

    if (!isValidUsername(username)) {
      return NextResponse.json(
        createApiResponse(false, null, 'Username must be 3-20 characters and contain only letters, numbers, and underscores'),
        { status: 400 }
      );
    }

    if (!isValidEmail(email)) {
      return NextResponse.json(
        createApiResponse(false, null, 'Invalid email format'),
        { status: 400 }
      );
    }

    if (!isValidPassword(password)) {
      return NextResponse.json(
        createApiResponse(false, null, 'Password must be at least 6 characters long'),
        { status: 400 }
      );
    }

    // Check if user already exists
    const existingUserByUsername = getUserByUsername(username);
    if (existingUserByUsername) {
      return NextResponse.json(
        createApiResponse(false, null, 'Username already exists'),
        { status: 409 }
      );
    }

    const existingUserByEmail = getUserByEmail(email);
    if (existingUserByEmail) {
      return NextResponse.json(
        createApiResponse(false, null, 'Email already exists'),
        { status: 409 }
      );
    }

    // Create new user
    const userId = uuidv4();
    const passwordHash = hashPassword(password);

    const dbUser = createUser({
      id: userId,
      username,
      email,
      password_hash: passwordHash,
      role: 'user',
      permissions: JSON.stringify({
        canRequest: true,
        canApprove: false,
        canManageUsers: false,
        canConfigureSettings: false,
        maxRequests: 10
      })
    });

    // Generate JWT token
    const token = generateToken(dbUser);
    const user = databaseUserToUser(dbUser);

    const response = NextResponse.json(
      createApiResponse(true, {
        user,
        token,
        expiresAt: new Date(Date.now() + parseInt(process.env.JWT_EXPIRES_IN || '3600') * 1000).toISOString()
      }, null, 'Registration successful')
    );

    // Set HTTP-only cookie
    const maxAge = parseInt(process.env.JWT_EXPIRES_IN || '3600');
    response.cookies.set('auth-token', token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      maxAge,
      path: '/'
    });

    return response;
  } catch (error) {
    console.error('Registration error:', error);
    return NextResponse.json(
      createApiResponse(false, null, 'Internal server error'),
      { status: 500 }
    );
  }
}
