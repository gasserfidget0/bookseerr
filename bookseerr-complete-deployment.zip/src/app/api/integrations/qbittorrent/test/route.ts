import { NextRequest, NextResponse } from 'next/server';
import { authenticateRequest } from '@/lib/auth';
import { createApiResponse } from '@/lib/utils';

export async function POST(request: NextRequest) {
  try {
    const user = authenticateRequest(request);
    if (!user || user.role !== 'admin') {
      return NextResponse.json(
        createApiResponse(false, null, 'Admin access required'),
        { status: 403 }
      );
    }

    const { url, username, password } = await request.json();

    if (!url || !username || !password) {
      return NextResponse.json(
        createApiResponse(false, null, 'URL, username, and password are required'),
        { status: 400 }
      );
    }

    // Mock QBittorrent connection test
    // In real implementation, this would make an actual API call to QBittorrent
    const mockSuccess = true;

    if (mockSuccess) {
      return NextResponse.json(
        createApiResponse(true, {
          status: 'connected',
          version: '4.6.5',
          preferences: {
            save_path: '/downloads',
            max_active_downloads: 3
          }
        }, null, 'Successfully connected to QBittorrent')
      );
    } else {
      return NextResponse.json(
        createApiResponse(false, null, 'Failed to connect to QBittorrent'),
        { status: 400 }
      );
    }
  } catch (error) {
    console.error('QBittorrent test error:', error);
    return NextResponse.json(
      createApiResponse(false, null, 'Internal server error'),
      { status: 500 }
    );
  }
}
