import { NextRequest, NextResponse } from 'next/server';
import { getSetting } from '@/lib/database';
import { authenticateRequest } from '@/lib/auth';
import { createApiResponse } from '@/lib/utils';

export async function POST(request: NextRequest) {
  try {
    const user = authenticateRequest(request);
    if (!user || user.role !== 'admin') {
      return NextResponse.json(
        createApiResponse(false, null, 'Admin access required'),
        { status: 403 }
      );
    }

    const { url, apiKey } = await request.json();

    if (!url || !apiKey) {
      return NextResponse.json(
        createApiResponse(false, null, 'URL and API key are required'),
        { status: 400 }
      );
    }

    // Mock Readarr connection test
    // In real implementation, this would make an actual API call to Readarr
    const mockSuccess = true;

    if (mockSuccess) {
      return NextResponse.json(
        createApiResponse(true, {
          status: 'connected',
          version: '0.4.18.2734',
          rootFolders: [
            { id: 1, path: '/books', accessible: true }
          ],
          qualityProfiles: [
            { id: 1, name: 'Standard' },
            { id: 2, name: 'High Quality' }
          ]
        }, null, 'Successfully connected to Readarr')
      );
    } else {
      return NextResponse.json(
        createApiResponse(false, null, 'Failed to connect to Readarr'),
        { status: 400 }
      );
    }
  } catch (error) {
    console.error('Readarr test error:', error);
    return NextResponse.json(
      createApiResponse(false, null, 'Internal server error'),
      { status: 500 }
    );
  }
}
