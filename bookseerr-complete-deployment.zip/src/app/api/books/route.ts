import { NextRequest, NextResponse } from 'next/server';
import { v4 as uuidv4 } from 'uuid';
import { searchBooks, createBook } from '@/lib/database';
import { authenticateRequest } from '@/lib/auth';
import { createApiResponse } from '@/lib/utils';

export async function GET(request: NextRequest) {
  try {
    const user = authenticateRequest(request);
    if (!user) {
      return NextResponse.json(
        createApiResponse(false, null, 'Authentication required'),
        { status: 401 }
      );
    }

    const { searchParams } = new URL(request.url);
    const query = searchParams.get('query') || undefined;
    const author = searchParams.get('author') || undefined;
    const category = searchParams.get('category') || undefined;
    const available = searchParams.get('available') ? searchParams.get('available') === 'true' : undefined;
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '20');

    const offset = (page - 1) * limit;

    const { books, total } = searchBooks({
      query,
      author,
      category,
      available,
      limit,
      offset
    });

    const pagination = {
      page,
      limit,
      total,
      totalPages: Math.ceil(total / limit)
    };

    return NextResponse.json(
      createApiResponse(true, { books, pagination })
    );
  } catch (error) {
    console.error('Get books error:', error);
    return NextResponse.json(
      createApiResponse(false, null, 'Internal server error'),
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const user = authenticateRequest(request);
    if (!user || user.role !== 'admin') {
      return NextResponse.json(
        createApiResponse(false, null, 'Admin access required'),
        { status: 403 }
      );
    }

    const bookData = await request.json();

    if (!bookData.title || !bookData.author) {
      return NextResponse.json(
        createApiResponse(false, null, 'Title and author are required'),
        { status: 400 }
      );
    }

    const book = createBook({
      id: uuidv4(),
      title: bookData.title,
      author: bookData.author,
      isbn: bookData.isbn,
      published_date: bookData.publishedDate,
      description: bookData.description,
      page_count: bookData.pageCount,
      categories: bookData.categories ? JSON.stringify(bookData.categories) : null,
      image_url: bookData.imageUrl,
      available: bookData.available || false,
      google_books_id: bookData.googleBooksId,
      goodreads_id: bookData.goodreadsId
    });

    return NextResponse.json(
      createApiResponse(true, book, null, 'Book created successfully')
    );
  } catch (error) {
    console.error('Create book error:', error);
    return NextResponse.json(
      createApiResponse(false, null, 'Internal server error'),
      { status: 500 }
    );
  }
}
