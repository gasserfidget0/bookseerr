import { NextRequest, NextResponse } from 'next/server';
import { getBookById, updateBook } from '@/lib/database';
import { authenticateRequest } from '@/lib/auth';
import { createApiResponse } from '@/lib/utils';

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const user = authenticateRequest(request);
    if (!user) {
      return NextResponse.json(
        createApiResponse(false, null, 'Authentication required'),
        { status: 401 }
      );
    }

    const book = getBookById(params.id);

    if (!book) {
      return NextResponse.json(
        createApiResponse(false, null, 'Book not found'),
        { status: 404 }
      );
    }

    return NextResponse.json(
      createApiResponse(true, book)
    );
  } catch (error) {
    console.error('Get book error:', error);
    return NextResponse.json(
      createApiResponse(false, null, 'Internal server error'),
      { status: 500 }
    );
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const user = authenticateRequest(request);
    if (!user || user.role !== 'admin') {
      return NextResponse.json(
        createApiResponse(false, null, 'Admin access required'),
        { status: 403 }
      );
    }

    const updates = await request.json();
    const book = updateBook(params.id, updates);

    if (!book) {
      return NextResponse.json(
        createApiResponse(false, null, 'Book not found'),
        { status: 404 }
      );
    }

    return NextResponse.json(
      createApiResponse(true, book, null, 'Book updated successfully')
    );
  } catch (error) {
    console.error('Update book error:', error);
    return NextResponse.json(
      createApiResponse(false, null, 'Internal server error'),
      { status: 500 }
    );
  }
}
