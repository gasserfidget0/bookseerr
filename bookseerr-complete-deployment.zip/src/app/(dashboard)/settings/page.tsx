import { SettingsTabs } from '@/components/settings/settings-tabs';
import { AdminOnly } from '@/components/auth/admin-only';

export default function SettingsPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-foreground">Settings</h1>
        <p className="text-muted-foreground">
          Configure your Bookseerr instance and integrations.
        </p>
      </div>

      <AdminOnly>
        <SettingsTabs />
      </AdminOnly>
    </div>
  );
}
