import { BookGrid } from '@/components/books/book-grid';
import { SearchAndFilters } from '@/components/books/search-and-filters';

export default function DiscoverPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-foreground">Discover Books</h1>
        <p className="text-muted-foreground">
          Find your next favorite book and add it to your request list.
        </p>
      </div>

      <SearchAndFilters />
      <BookGrid />
    </div>
  );
}
