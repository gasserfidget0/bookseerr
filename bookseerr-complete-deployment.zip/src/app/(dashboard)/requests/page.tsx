import { RequestsTable } from '@/components/requests/requests-table';

export default function RequestsPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-foreground">Requests</h1>
        <p className="text-muted-foreground">
          Manage all book requests in one place.
        </p>
      </div>

      <RequestsTable />
    </div>
  );
}
