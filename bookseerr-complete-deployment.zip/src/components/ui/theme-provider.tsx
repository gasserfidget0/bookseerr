export function ThemeProvider({ children }: { children: React.ReactNode }) {
  return <>{children}</>;
}
