'use client';

import { useAuth } from './auth-provider';

export function AdminOnly({ children }: { children: React.ReactNode }) {
  const { user } = useAuth();

  if (!user || user.role !== 'admin') {
    return (
      <div className="text-center py-12">
        <div className="max-w-md mx-auto">
          <div className="p-3 rounded-full bg-destructive/10 border border-destructive/20 w-fit mx-auto mb-4">
            <svg className="w-8 h-8 text-destructive" fill="currentColor" viewBox="0 0 24 24">
              <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
            </svg>
          </div>
          <h3 className="text-lg font-semibold text-foreground mb-2">Access Denied</h3>
          <p className="text-muted-foreground">
            You need administrator privileges to view this page.
          </p>
        </div>
      </div>
    );
  }

  return <>{children}</>;
}
