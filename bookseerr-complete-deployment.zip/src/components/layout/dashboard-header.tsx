'use client';

import { useAuth } from '@/components/auth/auth-provider';
import { Button } from '@/components/ui/button';
import { useRouter } from 'next/navigation';
import { toast } from '@/components/ui/toast';

export function DashboardHeader() {
  const { user, logout } = useAuth();
  const router = useRouter();

  const handleLogout = async () => {
    try {
      await logout();
      router.push('/login');
      toast.success('Logged out successfully');
    } catch (error) {
      toast.error('Logout failed');
    }
  };

  return (
    <header className="bg-card border-b border-border">
      <div className="px-4 lg:px-8 py-4">
        <div className="flex items-center justify-between">
          <div className="lg:hidden">
            <h1 className="text-xl font-bold text-foreground">Bookseerr</h1>
          </div>

          <div className="flex items-center space-x-4 ml-auto">
            <div className="hidden sm:flex items-center space-x-2 text-sm">
              <span className="text-muted-foreground">Welcome back,</span>
              <span className="font-medium text-foreground">{user?.username}</span>
            </div>

            <Button
              variant="ghost"
              size="sm"
              onClick={handleLogout}
              className="text-muted-foreground hover:text-foreground"
            >
              Logout
            </Button>
          </div>
        </div>
      </div>
    </header>
  );
}
